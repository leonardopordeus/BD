package br.com.ceiot.example.ceiot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.com.ceiot.example.ceiot.entity.Departamento;


// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

public interface DepartamentoRepository extends CrudRepository<Departamento, Integer> {    
    
    @Query("Select new Departamento(name) FROM Departamento WHERE name like %:name%")
    List<Departamento> listByName(@Param("name") String name);
   
    @Query(value = "SELECT name FROM departamento WHERE name like %:name%", nativeQuery = true)
    List<String> listByNameNative(@Param("name") String name);

}