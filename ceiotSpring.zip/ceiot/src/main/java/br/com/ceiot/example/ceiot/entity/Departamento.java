package br.com.ceiot.example.ceiot.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
//TODO: (2) Representação da Tabela na forma de classe
@Entity // This tells Hibernate to make a table out of this class
public class Departamento {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;    
	private String name;

	@OneToMany(mappedBy = "departamento")
	private List<Professor> professores;
	
	public Departamento()
	{
	}

	public Departamento(String name)
	{
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Professor> getProfessores() {
		return professores;
	}

	public void setProfessores(List<Professor> professores) {
		this.professores = professores;
	}


}