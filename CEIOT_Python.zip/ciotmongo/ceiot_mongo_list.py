import pymongo

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["ceiot_aula"]
mycollection = mydb["aluno"]

print("Busca tudo")
for x in mycollection.find():
  print(x)


print("Busca somente campo nome e Data Nascimento")

for x in mycollection.find({},{ "_id": 0, "nome": 1, "dataNascimento": 1}):
  print(x)

print("Busca com Query")
myquery = { "nome": "Aluno1" }

myResult = mycollection.find(myquery)
for x in myResult:
  print(x)