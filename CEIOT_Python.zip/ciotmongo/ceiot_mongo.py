import pymongo

myclient = pymongo.MongoClient("mongodb://localhost:27017/")

mydb = myclient["ceiot_aula"]

mycollection = mydb["aluno"]

aluno = { "nome": "Aluno1", "dataNascimento":"05/11/1985" }

x = mycollection.insert_one(aluno)
print(x)

listAluno = [
    { "nome": "Aluno2", "dataNascimento":"05/01/1991" },
    { "nome": "Aluno3", "dataNascimento":"15/05/1989" },
    { "nome": "Aluno4", "dataNascimento":"18/08/1994" }
    ]

x = mycollection.insert_many(listAluno)

print(x)