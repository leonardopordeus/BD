from django.db import models

# Create your models here.
class Aluno(models.Model):    
    nome = models.CharField(max_length=200)

class Departamento(models.Model):    
    name = models.CharField(max_length=200)

class Professor(models.Model):
    departemento = models.ForeignKey(Departamento, on_delete=models.CASCADE)
    nome = models.CharField(max_length=200)