from django.shortcuts import render
from django.http import HttpResponse
from django.core import serializers
from django.views.decorators.csrf import csrf_exempt
from exemploAula.models import Aluno, Departamento, Professor

# # Create your views here.

def hello(request):
   text = """<h1>welcome to my app !</h1>"""
   return HttpResponse(text)

def listAlunos(request):   
   list = serializers.serialize('json',  Aluno.objects.all())
   return HttpResponse(list, content_type="application/json")
   #return JsonResponse(list, safe=False)

def listAlunosByName(request):
   nome = request.GET['name']
   list = serializers.serialize('json',  Aluno.objects.all().filter(nome=nome))
   return HttpResponse(list, content_type="application/json")

def addAlunoGet(request):
   nome = request.GET['name']
   a = Aluno(nome=nome)
   a.save()      
   return HttpResponse(a, content_type="application/json")

@csrf_exempt
def addAluno(request):   
   print(request.body)
   for obj in serializers.deserialize("json", request.body):
    print(obj)
   # data=serializers.serialize('json',  request.body)
   # a = Aluno(nome=data['nome'])
   # a.save()   
   text = "Sucesso"
   return HttpResponse(text)
   # retorno = serializers.serialize('json',  a)
   # return HttpResponse(retorno, content_type="application/json")