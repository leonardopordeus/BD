from django.contrib import admin
from exemploAula.models import Aluno
from exemploAula.models import Departamento
from exemploAula.models import Professor

admin.site.register(Aluno)
admin.site.register(Departamento)
admin.site.register(Professor)