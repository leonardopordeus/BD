from django.apps import AppConfig


class ExemploaulaConfig(AppConfig):
    name = 'exemploAula'
