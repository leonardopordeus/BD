package br.com.ceiot.template_jdbc.resource;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.ceiot.template_jdbc.business.AlunoBusiness;
import br.com.ceiot.template_jdbc.entity.Aluno;
import br.com.ceiot.template_jdbc.filter.AlunoFilter;

@Path("/aluno")
public class AlunoResource {
	
	@GET	
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAluno(@QueryParam("id") Integer id)
	{
		AlunoBusiness alunoBusiness = new AlunoBusiness(); 
		Aluno aluno = alunoBusiness.getAluno(id);
		return Response.ok(aluno).build();		
	}

	@POST
	@Path("/listaAlunos")
	@Produces(MediaType.APPLICATION_JSON)
	public Response listaAlunos(AlunoFilter filtro)
	{		
		AlunoBusiness alunoBusiness = new AlunoBusiness(); 
		List<Aluno> listaAluno = alunoBusiness.listaAlunos(filtro);
		return Response.ok(listaAluno).build();
	}
	
	@POST
	@Path("/save")
	@Produces(MediaType.APPLICATION_JSON)
	public Response save(Aluno aluno)
	{		
		AlunoBusiness alunoBusiness = new AlunoBusiness(); 
		aluno = alunoBusiness.save(aluno);
		return Response.ok(aluno).build();
	}
	
	@DELETE
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Response delete(@QueryParam("id") Integer id)
	{		
		AlunoBusiness alunoBusiness = new AlunoBusiness(); 
		alunoBusiness.delete(id);
		return Response.ok().build();
	}
}
