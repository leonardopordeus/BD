package br.com.ceiot.template_jdbc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import br.com.ceiot.template_jdbc.entity.Aluno;
import br.com.ceiot.template_jdbc.filter.AlunoFilter;
import br.com.ceiot.template_jdbc.util.ConnectionFactory;

public class AlunoDao {

	public Aluno getAluno(int id) throws Exception {
		Statement statement = null;
		ResultSet resultSet = null;
		Aluno aluno = null;
		try {
			Connection connection = new ConnectionFactory().getConnection();

			statement = connection.createStatement();

			String sql = "SELECT ID, NOME, DT_NASCIMENTO FROM AULA_BD.ALUNO WHERE ID = " + id;

			resultSet = statement.executeQuery(sql);

			if (resultSet != null && resultSet.next()) {
				aluno = new Aluno(resultSet.getInt(1), resultSet.getString(2), resultSet.getDate(3));
			}

			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException sqlEx) {
				} // ignore

				resultSet = null;
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException sqlEx) {
				} // ignore

				statement = null;
			}
		}
		return aluno;
	}

	public List<Aluno> listaAlunos(AlunoFilter filtro) throws SQLException {
		Statement statement = null;
		ResultSet resultSet = null;
		List<Aluno> listAluno = new ArrayList<Aluno>();
		try {
			Connection connection = new ConnectionFactory().getConnection();
			System.out.println("Conex�o aberta!");
			statement = connection.createStatement();

			String sql = "SELECT ID, NOME, DT_NASCIMENTO " + "FROM AULA_BD.ALUNO " + "WHERE UPPER(NOME) LIKE '%"
					+ filtro.getNome().toUpperCase() + "%'";

			resultSet = statement.executeQuery(sql);

			if (resultSet != null) {

				while (resultSet.next()) {
					listAluno.add(new Aluno(resultSet.getInt(1), resultSet.getString(2), resultSet.getDate(3)));
				}
			}

			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException sqlEx) {
				} // ignore

				resultSet = null;
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException sqlEx) {
				} // ignore

				statement = null;
			}
		}
		return listAluno;
	}

	public Aluno save(Aluno aluno) {
		Statement statement = null;
		ResultSet resultSet = null;
	
		try {
			Connection connection = new ConnectionFactory().getConnection();

			statement = connection.createStatement();
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

			String sql = null;
			if(aluno.getId() == null || aluno.getId().equals(0))
			{
				sql = "INSERT INTO AULA_BD.ALUNO (NOME,DT_NASCIMENTO) VALUES "
						+ "('" + aluno.getNome() + "', "
						+ "DATE('" + df.format(aluno.getDtNascimento()) + "'))"
						;
				statement.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);
				resultSet = statement.getGeneratedKeys();
				if (resultSet != null && resultSet.next()) {
					aluno.setId(resultSet.getInt(1));
				}
			}
			else
			{
				sql = "UPDATE AULA_BD.ALUNO SET"
						+ " NOME = '" + aluno.getNome() + "', "
						+ " DT_NASCIMENTO = DATE('" + df.format(aluno.getDtNascimento()) + "') "
						+ " WHERE ID = " + aluno.getId()
						;
				statement.executeUpdate(sql);
			}
			
			//connection.commit();		

			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException sqlEx) {
				} // ignore

				resultSet = null;
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException sqlEx) {
				} // ignore

				statement = null;
			}
		}
		return aluno;
	}

	public void delete(Integer id) {
		Statement statement = null;
		ResultSet resultSet = null;
		
		try {
			Connection connection = new ConnectionFactory().getConnection();

			statement = connection.createStatement();

			String sql = "DELETE FROM AULA_BD.ALUNO WHERE ID = " + id;

			statement.executeUpdate(sql);

			//connection.commit();

			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException sqlEx) {
				} // ignore

				resultSet = null;
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException sqlEx) {
				} // ignore

				statement = null;
			}
		}
	}

}
