package br.com.ceiot.template_jdbc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import br.com.ceiot.template_jdbc.entity.Disciplina;
import br.com.ceiot.template_jdbc.util.ConnectionFactory;

public class DisciplinaDao {
	
	public Disciplina save(Disciplina disciplina) {
		Statement statement = null;
		ResultSet resultSet = null;
	
		try {
			Connection connection = new ConnectionFactory().getConnection();

			statement = connection.createStatement();				

			String sql = null;
			if(disciplina.getId() == null || disciplina.getId().equals(0))
			{
				sql = "INSERT INTO AULA_BD.DISCIPLINA (NOME,QTDE) VALUES ('"
						+ disciplina.getNome()
						+ "',"
						+ disciplina.getQtde().toString()
						+ ")";							
				
				statement.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);
				resultSet = statement.getGeneratedKeys();
				if (resultSet != null && resultSet.next()) {
					disciplina.setId(resultSet.getInt(1));
				}
			}
			else
			{
				sql = "UPDATE AULA_BD.DISCIPLINA SET"
						+ " NOME = '" + disciplina.getNome() 
						+ " WHERE ID = " + disciplina.getId()
						;
				statement.executeUpdate(sql);
			}
			
			//connection.commit();		

			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException sqlEx) {
				} // ignore

				resultSet = null;
			}

			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException sqlEx) {
				} // ignore

				statement = null;
			}
		}
		return disciplina;
	}

}
