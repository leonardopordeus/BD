package br.com.ceiot.template_jdbc.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.ceiot.template_jdbc.business.DisciplinaBusiness;
import br.com.ceiot.template_jdbc.entity.Disciplina;

@Path("/disciplina")
public class DisciplinaResource {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDisciplina(@QueryParam("nome") String nome)
	{
		Disciplina disciplina = new Disciplina();
		disciplina.setId(0);
		disciplina.setNome(nome);
		return Response.ok(disciplina).build();
	}
	
	@GET
	@Path("/save")
	@Produces(MediaType.APPLICATION_JSON)
	public Response saveDisciplina(@QueryParam("nome") String nome, @QueryParam("qtde") Integer qtde)
	{
		DisciplinaBusiness disciplinaBusiness = new DisciplinaBusiness();
		return Response.ok(disciplinaBusiness.gravaNovaDisciplina(nome,qtde)).build();
	}
	
}
