package br.com.ceiot.template_jdbc.business;

import java.util.List;

import javax.ws.rs.QueryParam;

import br.com.ceiot.template_jdbc.dao.AlunoDao;
import br.com.ceiot.template_jdbc.entity.Aluno;
import br.com.ceiot.template_jdbc.filter.AlunoFilter;

public class AlunoBusiness {

	public Aluno getAluno(int id) {
		try {
			AlunoDao alunoDao = new AlunoDao();			
			return alunoDao.getAluno(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Aluno> listaAlunos(AlunoFilter filtro) {
		try {
			AlunoDao alunoDao = new AlunoDao();			
			return alunoDao.listaAlunos(filtro);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Aluno save(Aluno aluno)
	{		
		try {
			AlunoDao alunoDao = new AlunoDao();			
			return alunoDao.save(aluno);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void delete(Integer id)
	{		
		try {
			AlunoDao alunoDao = new AlunoDao();			
			alunoDao.delete(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
