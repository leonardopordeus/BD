package br.com.ceiot.template_jdbc.filter;

public class AlunoFilter {

	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
