package br.com.ceiot.template_jdbc.business;

import br.com.ceiot.template_jdbc.dao.DisciplinaDao;
import br.com.ceiot.template_jdbc.entity.Disciplina;

public class DisciplinaBusiness {
	
	public Disciplina gravaNovaDisciplina(String nome,Integer qtde)
	{
		try
		{
			Disciplina disciplina = new Disciplina();
			disciplina.setId(0);
			disciplina.setNome(nome);
			disciplina.setQtde(qtde);;
			
			DisciplinaDao dao = new DisciplinaDao();
			return dao.save(disciplina);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
