package br.com.ceiot.template_jdbc.entity;

import java.io.Serializable;
import java.util.Date;

public class Aluno implements Serializable{

	private static final long serialVersionUID = 1312512186644670040L;
	private Integer id;
	private String nome;
	private Date dtNascimento;
	
	public Aluno()
	{
		super();
	}	

	public Aluno(Integer id, String nome, Date dtNascimento) {
		super();
		this.id = id;
		this.nome = nome;
		this.dtNascimento = dtNascimento;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setName(String nome) {
		this.nome = nome;
	}
	public Date getDtNascimento() {
		return dtNascimento;
	}
	public void setDtNascimento(Date dtNascimento) {
		this.dtNascimento = dtNascimento;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
