package br.com.ceiot.template_jdbc.entity;

import java.io.Serializable;

public class Disciplina implements Serializable{
		
	private static final long serialVersionUID = -2159634429344118784L;
	private Integer id;
	private String nome;
	private Integer qtde;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Integer getQtde() {
		return qtde;
	}
	public void setQtde(Integer qtde) {
		this.qtde = qtde;
	}
	
	

}
