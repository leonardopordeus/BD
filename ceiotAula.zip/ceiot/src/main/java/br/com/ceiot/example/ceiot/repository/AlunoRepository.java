package br.com.ceiot.example.ceiot.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.com.ceiot.example.ceiot.entity.Aluno;

public interface AlunoRepository extends CrudRepository<Aluno, Integer> {
    @Query("Select new Aluno() FROM Aluno WHERE name like %:name%")
    List<Aluno> listByName(@Param("name") String name);
}