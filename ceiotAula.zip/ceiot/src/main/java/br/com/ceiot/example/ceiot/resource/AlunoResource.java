package br.com.ceiot.example.ceiot.resource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.ceiot.example.ceiot.entity.Aluno;
import br.com.ceiot.example.ceiot.repository.AlunoRepository;

@Controller  
@RequestMapping(path="/aluno") 
public class AlunoResource {

    @Autowired
    AlunoRepository alunoRepository;
    
    @GetMapping(path="/add", produces = "application/json")
    public @ResponseBody Aluno addAluno(@RequestParam String name)
    {
        // return "Falta implementar!!!";
        Aluno aluno = new Aluno();
        aluno.setName(name);
        alunoRepository.save(aluno);
        return aluno;
    }

    @GetMapping(path="/list", produces = "application/json")
    public @ResponseBody Iterable<Aluno> listaALuno() 
    {
      return alunoRepository.findAll();
    }

    @GetMapping(path="/listByName", produces = "application/json")
    public @ResponseBody Iterable<Aluno> listaALunoByName(@RequestParam String name) 
    {
      return alunoRepository.listByName(name);
    }
}